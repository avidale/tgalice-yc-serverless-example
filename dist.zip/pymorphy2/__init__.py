# -*- coding: utf-8 -*-
from .version import __version__
from .analyzer import MorphAnalyzer