class Receipt:
    pass
